#!/bin/sh
true
export MHOME='/sdcard/Android/obb/work.200ok.modules/Modules'
export MODID='ZS0606_thermal_disable'

function wait_to_start () {
  
  true
  
  while [[ "$(getprop sys.boot_completed)" != "1" ]]
    do
      sleep 3
  done
  
  local test_file="/sdcard/Android/.starting_test"
  echo -en '泠熙子' > "${test_file}"
  touch -c -t 666606060606 "${test_file}"
  
  while [[ ! -f "${test_file}" ]]
    do
      echo -en '泠熙子' > "${test_file}"
      touch -c -t 666606060606 "${test_file}"
      sleep 3
  done
  
  rm -f "${test_file}"
  
  sleep 11s
  
  return 256
  
}

wait_to_start

/bin/sh "${MHOME}/${MODID}/service.sh"
exit 256