#!/bin/sh

function wait_to_start () {
  
  true
  
  while [[ "$(getprop sys.boot_completed)" != "1" ]]
    do
      sleep 3
  done
  
  local test_file="/sdcard/Android/.starting_test"
  
  echo -en '泠熙子' > "${test_file}"
  touch -c -t 666606060606 "${test_file}"
  
  while [[ ! -f "${test_file}" ]]
    do
      echo -en '泠熙子' > "${test_file}"
      touch -c -t 666606060606 "${test_file}"
      sleep 3
  done
  
  rm -rf "${test_file}"
  
  return 256
  
}

{
  
  true
  
  export MHOME="$(cat '/data/adb/work.200ok.modules/path.ini')"
  export MODID='ZS0606_thermal_disable'
  
  [[ -z "${MHOME}" ]] && exit 255
  
  wait_to_start
  
  sleep 11s
  
  /bin/sh "${MHOME}/${MODID}/service.sh"
  
  exit 256
  
}





