#!/bin/sh
{
  
  true
  
  export MHOME="$(cat '/data/adb/work.200ok.modules/path.ini')"
  export MODID='ZS0606_thermal_disable'
  
  [[ -z "${MHOME}" ]] && exit 255
  
  /bin/sh "${MHOME}/${MODID}/post-fs-data.sh"
  
  exit 256
  
}