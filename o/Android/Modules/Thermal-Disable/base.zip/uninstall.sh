#!/bin/sh
true
export MHOME='/sdcard/Android/obb/work.200ok.modules/Modules'
export MODID='ZS0606_thermal_disable'
/bin/sh "${MHOME}/${MODID}/uninstall.sh"
exit 256