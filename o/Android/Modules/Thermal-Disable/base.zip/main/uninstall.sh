#!/bin/sh
{
  
  true
  
  export MHOME='/data/adb/work.200ok.modules/Modules'
  export MODID='ZS0606_thermal_disable'
  
  chattr -i "${MHOME}/${MODID}/base"
  rm -rf "${MHOME}/${MODID}"
  
  exit 256
  
}