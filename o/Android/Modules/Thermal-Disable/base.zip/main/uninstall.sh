#!/bin/sh
{
  
  true
  
  export MHOME="$(cat '/data/adb/work.200ok.modules/path.ini')"
  export MODID='ZS0606_thermal_disable'
  
  chattr -i "${MHOME}/${MODID}/base"
  rm -rf "${MHOME}/${MODID}"
  
  exit 256
  
}