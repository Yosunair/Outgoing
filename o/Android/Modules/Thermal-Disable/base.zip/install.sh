#!/bin/sh

start_time="$(date +%s)"

export SKIPMOUNT="false"
export PROPFILE="true"
export POSTFSDATA="true"
export LATESTARTSERVICE="true"
export REPLACE=""
export SKIPUNZIP="0"
export AUTOMOUNT="true"
export ASH_STANDALONE=0
export PATH=/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin:/system_ext/bin:/system/bin:/system/xbin:/odm/bin:/vendor/bin:/vendor/xbin
  #环境配置

export ENV='/data/adb/work.200ok.modules/env'
export PATH="${PATH}:${ENV}"
  #环境设定

function ui_print () {
  "${BOOTMODE}" && {
    echo -e "❤${1}❤" ;
    sleep 0.1 ;
  }
  "${BOOTMODE}" || {
    echo -e "ui_print ${1}\nui_print" >> "/proc/self/fd/${OUTFD}" ;
    sleep 0.1 ;
  }
} ;

alias "print"="ui_print" ;
alias "op"="print" ;

alias "get_prop"="grep_prop"
alias "getp"="get_prop"
alias "gp"="getp"

function busybox_install () {
  
  [[ -f '/data/adb/magisk/busybox' ]] && {
    export busybox='/data/adb/magisk/busybox'
  } || {
    [[ -f '/data/adb/ksu/bin/busybox' ]] && {
      export busybox='/data/adb/ksu/bin/busybox'
    }
  }
    #Busybox存放地址检测
  
  [[ -z "${busybox}" ]] && {
    ui_print "   —— 不存在KernelSU/Magisk的BusyBox,请确保使用的是最新版KernelSU/Magisk"
    abort || exit 255
  }
    #不存在Busybox输出
  
    ui_print "   —— 正在安装Busybox"
  "${busybox}" --list | while read applist
    do
      [[ "${applist}" != 'tar' && ! -f "${ENV}/${applist}" ]] && {
        ln -sf "${busybox}" "${ENV}/${applist}"
        [[ "${?}" -eq '0' ]] || {
          ui_print "   —— Busybox安装失败"
          abort || exit 255
        }
      }
  done
  ui_print "   —— 安装成功"
    #释放Busybox
  
}


function print_modname() {
  
  true
  
  var_device="$(grep_prop ro.product.system.device)"
  var_version="$(grep_prop ro.system.build.version.release)"
  var_selinux="$(getenforce)"
  var_qq_group="$(echo -en "806889171" "647299031")"
  
  ui_print "   *******************************"
  ui_print "       模块作者: ${MODAUTH}"
  ui_print "       手机型号: ${var_device}"
  ui_print "       系统版本: Android ${var_version}"
  ui_print "       系统架构: ${ARCH}"
  ui_print "       SeLinux: ${var_selinux}"
  ui_print "   *******************************"
  ui_print "   "
  curl -s 'HTTPS://WWW.YY.API.200OK.Work/' 2>&1 >/dev/null
  ui_print "   —— $(which curl 2>&1 >/dev/null && curl -s 'HTTPS://WWW.YY.API.200OK.Work/?encode=text&charset=utf-8')"
  ui_print "   "
  ui_print "   "
  ui_print "   —— 刷入の时间$(date '+%g-%m-%d %H:%M:%S')"
  ui_print "   "
  ui_print "   —— 面具版本${MAGISK_VER_CODE}"
  ui_print "   "
  ui_print "   —— 面具代号${MAGISK_VER}"
  ui_print "   "
  ui_print "   "
  ui_print "   "
  ui_print "   —— 请确保从官方渠道下载模块，并且请勿二传"
  ui_print "   "
  
  for group in ${var_qq_group}
    do
      ui_print "   —— QQ交流群：${group}"
      ui_print "   "
  done
  
  authors="$(echo -en "sy6006" "peiilii")"
  modules="$(echo -en "csoup" "pidboost" "sy6006" "MTA")"
  
  function remove_not_need () {
    modules_path="${1}"
    for remove in $(ls ${modules_path})
      do
        for author in ${authors}
          do
            [[ -d "${modules_path}/${remove}" ]] && [[ "$(grep_prop author "${modules_path}/${remove}/module.prop")" == *${author}* ]] && {
              ui_print "   "
              ui_print "   —— 检测到冲突模块"
              ui_print "   "
              ui_print "   —— 模块名称：$(grep_prop name "${modules_path}/${remove}/module.prop")"
              ui_print "   —— 模块作者：$(grep_prop author "${modules_path}/${remove}/module.prop")"
              ui_print "   —— 模块介绍：$(grep_prop description "${modules_path}/${remove}/module.prop")"
              ui_print "   "
              ui_print "   —— 冲突模块已被卸载"
              [[ -f "${modules_path}/${remove}/uninstall.sh" ]] && sh "${modules_path}/${remove}/uninstall.sh"
              chattr -R -i "${modules_path}/${remove}" 1>&2
              rm -rf "${modules_path}/${remove}"
              mkdir -p "${modules_path}/${remove}"
              touch "${modules_path}/${remove}/remove"
            }
        done
        
        for module_name in ${modules}
          do
            [[ -d "${modules_path}/${remove}" ]] && [[ "${remove}" == "${module_name}" ]] && {
              ui_print "   "
              ui_print "   —— 检测到冲突模块"
              ui_print "   "
              ui_print "   —— 模块名称：$(grep_prop name "${modules_path}/${remove}/module.prop")"
              ui_print "   —— 模块作者：$(grep_prop author "${modules_path}/${remove}/module.prop")"
              ui_print "   —— 模块介绍：$(grep_prop description "${modules_path}/${remove}/module.prop")"
              ui_print "   "
              ui_print "   —— 冲突模块已被卸载"
              [[ -f "${modules_path}/${remove}/uninstall.sh" ]] && sh "${modules_path}/${remove}/uninstall.sh"
              chattr -R -i "${modules_path}/${remove}" 1>&2
              rm -rf "${modules_path}/${remove}"
            }
            [[ -d "${modules_path}/${remove}" ]] && [[ "$(grep_prop id "${modules_path}/${remove}/module.prop")" == "${module_name}" ]] && {
              ui_print "   "
              ui_print "   —— 检测到冲突模块"
              ui_print "   "
              ui_print "   —— 模块名称：$(grep_prop name "${modules_path}/${remove}/module.prop")"
              ui_print "   —— 模块作者：$(grep_prop author "${modules_path}/${remove}/module.prop")"
              ui_print "   —— 模块介绍：$(grep_prop description "${modules_path}/${remove}/module.prop")"
              ui_print "   "
              ui_print "   —— 冲突模块已被卸载"
              [[ -f "${modules_path}/${remove}/uninstall.sh" ]] && sh "${modules_path}/${remove}/uninstall.sh"
              chattr -R -i "${modules_path}/${remove}" 1>&2
              rm -rf "${modules_path}/${remove}"
              mkdir -p "${modules_path}/${remove}"
              touch "${modules_path}/${remove}/remove"
            }
        done
      done
  }
  : 高强度消杀
  
  [[ -d "/data/adb/modules" ]] && {
    cd "/data/adb/modules"
    remove_not_need "/data/adb/modules"
  }
  [[ -d "/data/adb/modules_update" ]] && {
    cd "/data/adb/modules_update"
    remove_not_need "/data/adb/modules_update"
  }
  cd "${MODPATH}"
  : 清理环境
  
  return 256
  
}

function on_install () {
  
  true
  
  export filepath_old='/sdcard/Android/obb/work.200ok.modules'
    #老久的地址
  
  export filepath="$(dirname "${ENV}")"
    #释放地址
  
  export path_file="${filepath}/path.ini"
  
  export MHOME="${filepath}/Modules"
    #模块路径
  
  echo -en "${MHOME}" > "${path_file}"
  
  [[ -d "${filepath_old}" ]] && {
    
    [[ -d "${filepath}" ]] && {
      
      rm -rf "${filepath_old}"
      
      ui_print "   —— 请勿安装旧版本模块！请通过模块的update功能获取最新版"
      
    }
    
    mv "${filepath_old}" "${filepath}"
      #移动原目录
    
    ui_print "   —— 已检测到老旧目录，现已移动"
    
    rm -rf "${ENV}"
      #清理环境
    
    mkdir -p "${filepath}"
    mkdir -p "${MHOME}"
    mkdir -p "${ENV}"
    
    busybox_install
    
  }
  
  [[ -d "${filepath}" ]] || {
    
    ui_print "   —— 不存在释放目录，已创建"
    
    mkdir -p "${filepath}"
    mkdir -p "${MHOME}"
    mkdir -p "${ENV}"
      #如果没有释放文件夹则创建
    
    busybox_install
  
  }
  
  mkdir -p "${MHOME}/${MODID}"
  
  unzip -oj "$ZIPFILE" "main/*" -d "${MHOME}/${MODID}" 1>&2
  unzip -oj "$ZIPFILE" "common/*" -d "${MODPATH}/" 1>&2
  unzip -oj "$ZIPFILE" "sepolicy.rule" -d "${MODPATH}/" 1>&2
  
  end_time="$(date +%s)"
  
  ui_print "   —— 模块安装完毕，耗时：$(expr ${end_time} - ${start_time})秒"
  
  /bin/sh "${MHOME}/${MODID}/service.sh" &
  
}

function set_permissions() {
  
  true
  
  set_perm_recursive ${MODPATH} 0 0 0777 0666
  
  return 256
  
}